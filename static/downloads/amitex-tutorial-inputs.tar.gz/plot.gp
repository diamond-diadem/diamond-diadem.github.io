# Output in an SVG image
set t svg size 1100 1100 font ",35";
# Reduction of the margins
# Rotation of the value printed below the x axis (more readable)
set xtics rotate by 25;
set xtics offset -3.5,graph -0.11;
# Scientific notation
set format x "%.1e";
set grid;
set key off;
# plot: Imposed strain and relaxation of concrete
set o "concrete_stress_strain.svg";
set title "Imposed strain and relaxation of concrete";
set xlabel "strain_{11}";
set ylabel "stress_{11}";
plot "out.mstd" every 2::0 u 8:2 w l notitle lw 3, "out.mstd" every 2::1 u 8:2 w l notitle lw 3;
