import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DEFAULT_DATA = Path(__file__).resolve().parent.parent / "work-train" / "learning-curve.out"


def read_learning_curve(path):
    epoch, e_train, e_test, f_train, f_test = [], [], [], [], []
    with open(path) as fh:
        for line in fh:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            col = line.split()
            epoch.append(float(col[0]))
            e_train.append(float(col[1]))
            e_test.append(float(col[2]))
            f_train.append(float(col[9]))
            f_test.append(float(col[10]))
    return epoch, e_train, e_test, f_train, f_test


def main():
    parser = argparse.ArgumentParser(description="Plot NNP learning residuals from learning-curve.out")
    parser.add_argument("data", nargs="?", default=DEFAULT_DATA, type=Path, help=f"path to learning-curve.out (default: {DEFAULT_DATA})")
    parser.add_argument("-o", "--output", default="learning_curve.png", type=Path, help="output PNG path (default: learning_curve.png)")
    args = parser.parse_args()

    epoch, e_train, e_test, f_train, f_test = read_learning_curve(args.data)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(epoch, f_train, marker="o", ms=3, label="RMSE forces, train")
    ax.plot(epoch, f_test, marker="s", ms=3, label="RMSE forces, test")
    ax.plot(epoch, e_train, marker="^", ms=3, ls="--", label="RMSE energies/atom, train")
    ax.plot(epoch, e_test, marker="v", ms=3, ls="--", label="RMSE energies/atom, test")

    ax.set_yscale("log")
    ax.set_xlabel("epoch")
    ax.set_ylabel("RMSE (physical units)")
    ax.set_title("NNP learning residuals")
    ax.grid(True, which="both", alpha=0.3)
    fig.legend(loc="upper right", bbox_to_anchor=(1, 1))
    fig.tight_layout()
    fig.savefig(args.output)
    print(f"saved: {args.output}")


if __name__ == "__main__":
    main()
