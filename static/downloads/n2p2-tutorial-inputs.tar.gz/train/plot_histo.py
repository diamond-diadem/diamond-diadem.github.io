import numpy as np
import matplotlib.pyplot as plt

filename = 'sf.016.0064.histo'

data = np.loadtxt(filename, comments='#')
bin_centers = (data[:, 0] + data[:, 1]) / 2
bin_width = data[:, 1] - data[:, 0]

plt.bar(bin_centers, data[:, 2], width=bin_width)
plt.xlabel('Symmetry Function Value')
plt.ylabel('Count')
plt.title(filename)
plt.show()